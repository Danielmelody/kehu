/*window.onload=function(){
    alert(window.location.pathname);
}*/